#!/bin/sh
mkdir /root/dectector
mkdir /root/dectector/log
mkdir /root/dectector/before_transform
mkdir /root/dectector/after_transform
mkdir /root/detector/match
mkdir /detector/policy
touch /root/detector/log/filematch.log 
touch /root/detector/log/filenomatch.log 
touch /root/detector/log/client.log 
touch /root/detector/policy/keyword.plc
